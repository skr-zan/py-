package test;

import com.alibaba.fastjson.JSONObject;
import com.boot.controller.AdminController;
import com.boot.entity.Admin;
import com.boot.service.AdminService;
import com.boot.util.VeDate;
import org.junit.jupiter.api.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AdminControllerTest {

    @Mock
    private AdminService adminService;

    @InjectMocks
    private AdminController adminController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // 初始化Mock注解
    }

    @AfterEach
    void tearDown() {
        // 清理操作（如果需要）
    }

    @Test
    void editpwd() {
        // 测试修改密码功能
        String jsonStr = "{\"adminid\":\"A20250520122314126\", \"password\":\"oldPass\", \"repassword\":\"newPass\"}";
        Admin admin = new Admin();
        admin.setAdminid("A20250520122314126");
        admin.setPassword("oldPass");
        when(adminService.getAdminById("A20250520122314126")).thenReturn(admin);

        Map<String, Object> result = adminController.editpwd(jsonStr);

        assertTrue((Boolean) result.get("success"));
        assertEquals("修改成功", result.get("message"));
        verify(adminService).updateAdmin(admin);
    }

    @Test
    void createAdmin() {
        // 测试创建管理员预处理
        Map<String, Object> result = adminController.createAdmin();
        assertNotNull(result.get("today"));
        assertEquals(VeDate.getStringDateShort(), result.get("today"));
    }

    @Test
    void insertAdmin() {
        // 测试新增管理员
        String jsonStr = "{\"username\":\"zhangzan\", \"password\":\"zhangzan\", \"realname\":\"Admin\", \"contact\":\"13888888888\"}";
        Admin admin = new Admin();
        admin.setUsername("zhangzan");
        admin.setPassword("zhangzan");
        admin.setRealname("Admin");
        admin.setContact("13888888888");
        admin.setAddtime(VeDate.getStringDateShort());
        when(adminService.insertAdmin(admin)).thenReturn(1); // 模拟插入成功，返回1

        Map<String, Object> result = adminController.insertAdmin(jsonStr);

        assertTrue((Boolean) result.get("success")); // 验证success为true
        assertEquals("保存成功", result.get("message")); // 验证message为"保存成功"
        verify(adminService).insertAdmin(admin); // 验证insertAdmin方法被正确调用
    }

    @Test
    void deleteAdmin() {
        // 测试删除单个管理员
        when(adminService.deleteAdmin("A20250520122314126")).thenReturn(1);

        Map<String, Object> result = adminController.deleteAdmin("A20250520122314126");

        assertTrue((Boolean) result.get("success"));
        assertEquals("删除成功", result.get("message"));
        verify(adminService).deleteAdmin("A20250520122314126");
    }

    @Test
    void deleteAdminByIds() {
        // 测试批量删除管理员
        String[] ids = {"A20250520122314126", "A20250520122314127"};
        when(adminService.deleteAdmin("A20250520122314126")).thenReturn(1);
        when(adminService.deleteAdmin("A20250520122314127")).thenReturn(1);

        Map<String, Object> result = adminController.deleteAdminByIds(ids);

        assertTrue((Boolean) result.get("success"));
        assertEquals("删除成功", result.get("message"));
        verify(adminService, times(2)).deleteAdmin(anyString());
    }

    @Test
    void updateAdmin() {
        // 测试更新管理员信息
        String jsonStr = "{\"adminid\":\"A20250520122314126\", \"username\":\"updatedUser\", \"realname\":\"Updated\", \"contact\":\"456\"}";
        Admin admin = new Admin();
        admin.setAdminid("A20250520122314126");
        admin.setUsername("updatedUser");
        admin.setRealname("Updated");
        admin.setContact("456");
        when(adminService.getAdminById("A20250520122314126")).thenReturn(admin);
        when(adminService.updateAdmin(admin)).thenReturn(1);

        Map<String, Object> result = adminController.updateAdmin(jsonStr);

        assertTrue((Boolean) result.get("success"));
        assertEquals("修改成功", result.get("message"));
        verify(adminService).updateAdmin(admin);
    }

    @Test
    void getAllAdmin() {
        // 测试获取所有管理员
        List<Admin> adminList = new ArrayList<>();
        Admin admin1 = new Admin();
        admin1.setAdminid("A20250520122314126");
        admin1.setUsername("zhangzan");
        admin1.setPassword("zhangzan");
        admin1.setRealname("Admin");
        admin1.setContact("13888888888");
        admin1.setAddtime("2025-05-20");
        adminList.add(admin1);
        when(adminService.getAllAdmin()).thenReturn(adminList);

        List<Admin> result = adminController.getAllAdmin();

        assertNotNull(result);
        assertEquals(1, result.size());
        verify(adminService).getAllAdmin();
    }

    @Test
    void getAdminMap() {
        // 测试模糊查询管理员
        List<Admin> adminList = new ArrayList<>();
        Admin admin1 = new Admin();
        admin1.setAdminid("A20250520122314126");
        admin1.setUsername("zhangzan");
        admin1.setPassword("zhangzan");
        admin1.setRealname("Admin");
        admin1.setContact("13888888888");
        admin1.setAddtime("2025-05-20");
        adminList.add(admin1);
        when(adminService.getAdminByLike(any(Admin.class))).thenReturn(adminList);

        Map<String, Object> result = adminController.getAdminMap("zhangzan");

        assertNotNull(result);
        assertEquals(1, result.get("total"));
        assertEquals(adminList, result.get("data"));
        verify(adminService).getAdminByLike(any(Admin.class));
    }

    @Test
    void getAdminByPage() {
        // 测试分页查询管理员
        List<Admin> adminList = new ArrayList<>();
        Admin admin1 = new Admin();
        admin1.setAdminid("A20250520122314126");
        admin1.setUsername("zhangzan");
        admin1.setPassword("zhangzan");
        admin1.setRealname("Admin");
        admin1.setContact("13888888888");
        admin1.setAddtime("2025-05-20");
        adminList.add(admin1);
        when(adminService.getAllAdmin()).thenReturn(adminList);

        Map<String, Object> result = adminController.getAdminByPage(1, 10);

        assertNotNull(result);
        assertEquals(1, result.get("count"));
        assertEquals(adminList, result.get("data"));
        verify(adminService).getAllAdmin();
    }

    @Test
    void getAdmin() {
        // 测试带关键词的分页查询
        List<Admin> adminList = new ArrayList<>();
        Admin admin1 = new Admin();
        admin1.setAdminid("A20250520122314126");
        admin1.setUsername("zhangzan");
        admin1.setPassword("zhangzan");
        admin1.setRealname("Admin");
        admin1.setContact("13888888888");
        admin1.setAddtime("2025-05-20");
        adminList.add(admin1);
        when(adminService.getAdminByLike(any(Admin.class))).thenReturn(adminList);

        Map<String, Object> result = adminController.getAdmin(1, 10, "zhangzan");

        assertNotNull(result);
        assertEquals(0, result.get("count"));
        assertEquals(adminList, result.get("data"));
        verify(adminService).getAdminByLike(any(Admin.class));
    }

    @Test
    void getAdminById() {
        // 测试按ID查询管理员
        Admin admin = new Admin();
        admin.setAdminid("A20250520122314126");
        admin.setUsername("zhangzan");
        admin.setPassword("zhangzan");
        admin.setRealname("Admin");
        admin.setContact("13888888888");
        admin.setAddtime("2025-05-20");
        when(adminService.getAdminById("A20250520122314126")).thenReturn(admin);

        Admin result = adminController.getAdminById("A20250520122314126");

        assertNotNull(result);
        assertEquals("A20250520122314126", result.getAdminid());
        assertEquals("zhangzan", result.getUsername());
        verify(adminService).getAdminById("A20250520122314126");
    }
}