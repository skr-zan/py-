package com.boot.controller;

import com.alibaba.fastjson.JSONObject;
import com.boot.entity.Wuye;
import com.boot.service.WuyeService;
import com.boot.util.VeDate;
import com.github.pagehelper.Page;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController // 定义为控制器，返回JSON类型数据
@RequestMapping(value = "/wuye", produces = "application/json; charset=utf-8") // 设置请求路径
@CrossOrigin // 允许跨域访问其资源
public class WuyeController extends BaseController{

    @Autowired // 自动注入依赖的ServiceBean
    private WuyeService wuyeService;

    @PostMapping("editpwd.action") // 定义访问方法路径
    @ResponseBody // 将java对象转为json格式的数据
    public Map<String, Object> editpwd(@RequestBody String jsonStr) {
        JSONObject obj = JSONObject.parseObject(jsonStr); // 将传递的Json参数转换成对象类型
        String wuyeid = obj.getString("wuyeid"); // 主键
        String password = obj.getString("password"); // 原密码
        String repassword = obj.getString("repassword"); // 新密码
        Map<String, Object> map = new HashMap<>(); // 定义Map其为返回值
        Wuye wuye = this.wuyeService.getWuyeById(wuyeid); //
        if (password.equals(wuye.getPassword())) { // 校验原密码是否正确
            wuye.setPassword(repassword); // 重置密码
            this.wuyeService.updateWuye(wuye); // 更新数据
            map.put("success", true);
            map.put("message", "修改成功");
        } else {
            map.put("success", false);
            map.put("message", "旧密码错误");
        }
        return map;
    }

    // 预处理 获取基础参数
    @GetMapping(value = "createWuye.action")
    @ResponseBody // 将java对象转为json格式的数据返回
    public Map<String, Object> createWuye() {
        Map<String, Object> map = new HashMap<>();
        map.put("today", VeDate.getStringDateShort());
        return map;
    }
    // 物业管理人员登录
    @PostMapping("login.action")
    @ResponseBody // 将java对象转为json格式的数据
    public Map<String, Object> login(@RequestBody String jsonStr) {
        Map<String, Object> map = new HashMap<>();
        JSONObject obj = JSONObject.parseObject(jsonStr);
        String username = obj.getString("username");
        String password = obj.getString("password");
        Wuye wuyeEntity = new Wuye();
        wuyeEntity.setUsername(username);
        List<Wuye> wuyeList = this.wuyeService.getWuyeByCond(wuyeEntity);
        if (wuyeList.size() == 0) {
            map.put("success", false);
            map.put("message", "用户名不存在");
        } else {
            Wuye wuye = wuyeList.get(0);
            if (password.equals(wuye.getPassword())) {
                map.put("success", true);
                map.put("message", "登录成功");
                map.put("wuyeid", wuye.getWuyeid());
                map.put("username", wuye.getUsername());
                map.put("realname", wuye.getRealname());
                map.put("role", "物业管理人员");
            } else {
                map.put("success", false);
                map.put("message", "密码错误");
            }
        }
        return map;
    }

    // 新增物业管理
    @PostMapping(value = "insertWuye.action")
    @ResponseBody // 将java对象转为json格式的数据返回
    public Map<String, Object> insertWuye(@RequestBody String jsonStr) {
        Map<String, Object> map = new HashMap<>();
        JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
        Wuye wuye = new Wuye();
        wuye.setUsername(obj.getString("username")); // 为用户名赋值
        wuye.setPassword(obj.getString("password")); // 为密码赋值
        wuye.setRealname(obj.getString("realname")); // 为姓名赋值
        wuye.setContact(obj.getString("contact")); // 为联系方式赋值
        wuye.setAddtime(VeDate.getStringDateShort()); // 为创建日期赋值
        int num = this.wuyeService.insertWuye(wuye);
        if (num > 0) {
            map.put("success", true);
            map.put("code", num);
            map.put("message", "保存成功");
        } else {
            map.put("success", false);
            map.put("code", num);
            map.put("message", "保存失败");
        }
        return map;
    }

    // 按主键删除一个物业管理
    @GetMapping(value = "deleteWuye.action")
    @ResponseBody // 将java对象转为json格式的数据返回
    public Map<String, Object> deleteWuye(String id) {
        Map<String, Object> map = new HashMap<>();
        int num = this.wuyeService.deleteWuye(id);
        if (num > 0) {
            map.put("success", true);
            map.put("code", num);
            map.put("message", "删除成功");
        } else {
            map.put("success", false);
            map.put("code", num);
            map.put("message", "删除失败");
        }
        return map;
    }

    // 按主键批量删除物业管理
    @PostMapping(value = "deleteWuyeByIds.action")
    @ResponseBody // 将java对象转为json格式的数据返回
    public Map<String, Object> deleteWuyeByIds(@RequestBody String[] ids) {
        int num = 0;
        for (String wuyeid : ids) {
            num += this.wuyeService.deleteWuye(wuyeid);
        }
        Map<String, Object> map = new HashMap<>();
        if (num > 0) {
            map.put("success", true);
            map.put("code", num);
            map.put("message", "删除成功");
        } else {
            map.put("success", false);
            map.put("code", num);
            map.put("message", "删除失败");
        }
        return map;
    }

    // 修改物业管理
    @PostMapping(value = "updateWuye.action")
    @ResponseBody // 将java对象转为json格式的数据返回
    public Map<String, Object> updateWuye(@RequestBody String jsonStr) {
        JSONObject obj = JSONObject.parseObject(jsonStr); // 将JSON字符串转换成object
        Wuye wuye = this.wuyeService.getWuyeById(obj.getString("wuyeid")); // 获取object中wuyeid字段
        wuye.setUsername(obj.getString("username")); // 为用户名赋值
        wuye.setRealname(obj.getString("realname")); // 为姓名赋值
        wuye.setContact(obj.getString("contact")); // 为联系方式赋值

        Map<String, Object> map = new HashMap<>();
        int num = this.wuyeService.updateWuye(wuye);
        if (num > 0) {
            map.put("success", true);
            map.put("code", num);
            map.put("message", "修改成功");
        } else {
            map.put("success", false);
            map.put("code", num);
            map.put("message", "修改失败");
        }
        return map;
    }

    // 查询全部物业管理数据 在下拉菜单中显示
    @GetMapping(value = "getAllWuye.action")
    @ResponseBody // 将java对象转为json格式的数据返回
    public List<Wuye> getAllWuye() {
        return this.wuyeService.getAllWuye();
    }

    // 查询全部物业管理数据 在下拉菜单中显示
    @GetMapping(value = "getWuyeMap.action")
    @ResponseBody // 将java对象转为json格式的数据返回
    public Map<String, Object> getWuyeMap(String keywords) {
        Map<String, Object> map = new HashMap<>();
        Wuye wuye = new Wuye();
        wuye.setUsername(keywords);
        List<Wuye> list = this.wuyeService.getWuyeByLike(wuye);
        map.put("data", list);
        map.put("total", list.size());
        return map;
    }

    // 通过AJAX在表格中显示物业管理数据
    @GetMapping(value = "getWuyeByPage.action")
    @ResponseBody // 将java对象转为json格式的数据返回
    public Map<String, Object> getWuyeByPage(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer limit) {
        // 定义一个Map对象 用来返回数据
        Map<String, Object> map = new HashMap<>();
        Page<Wuye> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
        List<Wuye> list = this.wuyeService.getAllWuye();
        // 返回的map中定义数据格式
        map.put("count", pager.getTotal());
        map.put("total", list.size());
        map.put("data", list);
        map.put("code", 0);
        map.put("msg", "");
        map.put("page", page);
        map.put("limit", limit);
        return map;
    }

    // 通过AJAX在表格中显示物业管理数据
    @GetMapping(value = "getWuye.action")
    @ResponseBody // 将java对象转为json格式的数据返回
    public Map<String, Object> getWuye(@RequestParam(defaultValue = "1") Integer page, @RequestParam(defaultValue = "10") Integer limit, String keywords) {
        // 定义一个Map对象 用来返回数据
        Map<String, Object> map = new HashMap<>();
        Page<Wuye> pager = com.github.pagehelper.PageHelper.startPage(page, limit);// 定义当前页和分页条数
        Wuye wuye = new Wuye();
        wuye.setUsername(keywords);
        List<Wuye> list = this.wuyeService.getWuyeByLike(wuye); // 返回的map中定义数据格式
        map.put("count", pager.getTotal());
        map.put("total", list.size());
        map.put("data", list);
        map.put("code", 0);
        map.put("msg", "");
        map.put("page", page);
        map.put("limit", limit);
        return map;
    }

    // 按主键查询物业管理数据
    @GetMapping(value = "getWuyeById.action")
    @ResponseBody // 将java对象转为json格式的数据返回
    public Wuye getWuyeById(String id) {
        Wuye wuye = this.wuyeService.getWuyeById(id);
        return wuye;
    }
}

