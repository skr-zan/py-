package com.boot.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.alibaba.fastjson.JSONObject;
import com.boot.entity.Users;
import com.boot.service.UsersService;

@RestController // 定义为控制器，返回JSON类型数据
@RequestMapping(value = "/register", produces = "application/json; charset=utf-8") // 设置请求路径
@CrossOrigin // 允许从不同的域访问其资源
public class RegisterController extends BaseController {

    // 自动注入依赖的ServiceBean
    @Autowired
    private UsersService usersService;

    // 用户注册
    @PostMapping(value = "register.action")
    @ResponseBody // 将java对象转为json格式的数据
    public Map<String, Object> register(@RequestBody String jsonStr) {
        Map<String, Object> map = new HashMap<>();
        JSONObject obj = JSONObject.parseObject(jsonStr);
        Users user = new Users();
        user.setUsername(obj.getString("username"));
        user.setPassword(obj.getString("password"));
        user.setRealname(obj.getString("realname"));
        user.setSex(obj.getString("sex"));
        user.setBirthday(obj.getString("birthday"));
        user.setBuildsid(obj.getString("buildsid"));
        user.setAddress(obj.getString("address"));
        user.setContact(obj.getString("contact"));
        user.setAddtime(obj.getString("addtime"));
        user.setMemo(obj.getString("memo"));

        // 检查用户是否已存在
        Users checkUser = usersService.getUsersById(obj.getString("username"));
        if (checkUser != null) {
            map.put("success", false);
            map.put("message", "用户名已存在");
            return map;
        }

        // 插入新用户
        int num = usersService.insertUsers(user);
        if (num > 0) {
            map.put("success", true);
            map.put("code", num);
            map.put("message", "保存成功");
        } else {
            map.put("success", false);
            map.put("code", num);
            map.put("message", "保存失败");
        }
        return map;
    }
}