package com.boot.entity;

import com.alibaba.fastjson.JSONObject;
import com.boot.util.VeDate;

// 物业管理表的实体类
public class Wuye {
    private String wuyeid = "W" + VeDate.getStringId(); // 生成主键编号
    private String username; // 用户名
    private String password; // 密码
    private String realname; // 真实姓名
    private String contact; // 联系方式
    private String addtime; // 创建日期

    // 省略其他字段的getter和setter方法...

    public String getWuyeid() {
        return this.wuyeid;
    }

    public void setWuyeid(String wuyeid) {
        this.wuyeid = wuyeid;
    }

    public String getUsername() {
        return this.username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRealname() {
        return this.realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getContact() {
        return this.contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getAddtime() {
        return this.addtime;
    }

    public void setAddtime(String addtime) {
        this.addtime = addtime;
    }

    // 重载方法 生成JSON类型字符串
    @Override
    public String toString() {
        return this.toJsonString();
    }

    // 直接转换成JSON字符串
    private String toJsonString() {
        JSONObject jsonString = new JSONObject();
        jsonString.put("wuyeid", this.wuyeid); // 主键编号
        jsonString.put("username", this.username); // 用户名
        jsonString.put("password", this.password); // 密码
        jsonString.put("realname", this.realname); // 真实姓名
        jsonString.put("contact", this.contact); // 联系方式
        jsonString.put("addtime", this.addtime); // 创建日期
        return jsonString.toString();
    }
}