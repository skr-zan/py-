package com.boot.dao;

import com.boot.entity.Wuye;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("wuyeDAO") // Repository标签定义数据库连接的访问 Spring中直接扫描加载
@Mapper // 不需要在spring配置中设置扫描地址 spring将动态的生成Bean后注入到WuyeServiceImpl中
public interface WuyeDAO {

    /**
     * WuyeDAO 接口 可以按名称直接调用wuye.xml配置文件的SQL语句
     */

    // 插入物业管理表数据 调用mapper包wuye.xml里的insertWuye配置 返回值0(失败),1(成功)
    int insertWuye(Wuye wuye);

    // 更新物业管理表数据 调用mapper包wuye.xml里的updateWuye配置 返回值0(失败),1(成功)
    int updateWuye(Wuye wuye);

    // 按主键删除物业管理表数据 调用mapper包wuye.xml里的deleteWuye配置 返回值0(失败),1(成功)
    int deleteWuye(String wuyeid);

    // 批量删除物业管理表数据 调用mapper包wuye.xml里的deleteWuyeByIds配置 返回值0(失败),大于0(成功)
    int deleteWuyeByIds(String[] ids);

    // 查询物业管理表全部数据 调用mapper包wuye.xml里的getAllWuye配置 返回List<Wuye>类型的数据
    List<Wuye> getAllWuye();

    // 按照Wuye类里面的值精确查询 调用mapper包wuye.xml里的getWuyeByCond配置 返回List<Wuye>类型的数据
    List<Wuye> getWuyeByCond(Wuye wuye);

    // 按照Wuye类里面的值模糊查询 调用mapper包wuye.xml里的getWuyeByLike配置 返回List<Wuye>类型的数据
    List<Wuye> getWuyeByLike(Wuye wuye);

    // 按主键查询物业管理表返回单一的Wuye实例 调用mapper包wuye.xml里的getWuyeById配置
    Wuye getWuyeById(String wuyeid);
}