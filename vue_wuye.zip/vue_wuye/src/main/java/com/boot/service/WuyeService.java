package com.boot.service;

import com.boot.entity.Wuye;
import java.util.List;

import org.springframework.stereotype.Service;

@Service("wuyeService") // 自动注册到Spring容器，不需要再在xml文件定义bean
public interface WuyeService {
    // 插入物业管理表数据 调用wuyeDAO里的insertWuye配置
    public int insertWuye(Wuye wuye);

    // 更新物业管理表数据 调用wuyeDAO里的updateWuye配置
    public int updateWuye(Wuye wuye);

    // 按主键删除物业管理表数据 调用wuyeDAO里的deleteWuye配置
    public int deleteWuye(String wuyeid);

    // 批量删除物业管理表数据 调用wuyeDAO里的deleteWuyeByIds配置 返回值0(失败),大于0(成功)
    public int deleteWuyeByIds(String[] ids);

    // 查询全部物业管理数据 调用wuyeDAO里的getAllWuye配置
    public List<Wuye> getAllWuye();

    // 按照Wuye类里面的字段名称精确查询 调用wuyeDAO里的getWuyeByCond配置
    public List<Wuye> getWuyeByCond(Wuye wuye);

    // 按照Wuye类里面的字段名称模糊查询 调用wuyeDAO里的getWuyeByLike配置
    public List<Wuye> getWuyeByLike(Wuye wuye);

    // 按主键查询物业管理表返回单一的Wuye实例 调用wuyeDAO里的getWuyeById配置
    public Wuye getWuyeById(String wuyeid);
}