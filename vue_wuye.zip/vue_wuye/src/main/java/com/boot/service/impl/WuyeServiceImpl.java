package com.boot.service.impl;

import com.boot.dao.WuyeDAO;
import com.boot.entity.Wuye;
import com.boot.service.WuyeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service("wuyeService") // 自动注册到Spring容器，不需要再在xml文件定义bean
public class WuyeServiceImpl implements WuyeService {
    @Autowired // 它可以对类成员变量、方法及构造函数进行标注，完成自动装配的工作
    private WuyeDAO wuyeDAO;

    @Override // 继承接口的新增物业管理表数据 返回值0(失败),1(成功)
    public int insertWuye(Wuye wuye) {
        return this.wuyeDAO.insertWuye(wuye);
    }

    @Override // 继承接口的更新物业管理表数据 返回值0(失败),1(成功)
    public int updateWuye(Wuye wuye) {
        return this.wuyeDAO.updateWuye(wuye);
    }

    @Override // 继承接口的按主键删除物业管理表数据 返回值0(失败),1(成功)
    public int deleteWuye(String wuyeid) {
        return this.wuyeDAO.deleteWuye(wuyeid);
    }

    @Override // 继承接口的批量删除物业管理表数据 返回值0(失败),大于0(成功)
    public int deleteWuyeByIds(String[] ids) {
        return this.wuyeDAO.deleteWuyeByIds(ids);
    }

    @Override // 继承接口的查询物业管理表全部数据
    public List<Wuye> getAllWuye() {
        return this.wuyeDAO.getAllWuye();
    }

    @Override // 继承接口的按条件精确查询物业管理表数据
    public List<Wuye> getWuyeByCond(Wuye wuye) {
        return this.wuyeDAO.getWuyeByCond(wuye);
    }

    @Override // 继承接口的按条件模糊查询物业管理表数据
    public List<Wuye> getWuyeByLike(Wuye wuye) {
        return this.wuyeDAO.getWuyeByLike(wuye);
    }

    @Override // 继承接口的按主键查询物业管理表数据 返回Entity实例
    public Wuye getWuyeById(String wuyeid) {
        return this.wuyeDAO.getWuyeById(wuyeid);
    }
}